ApexScout AI - Image Dataset (SAMPLE)

Contains 15 PNG sports-action samples for each of 6 sports.
These images were generated as sample visual data and should be treated as a prototype/demo dataset, not as a verified real-world training dataset.
